package com.exampleSpringBoot.demo.ControllerHealth;public class HealthController {
}
